#2C2230005/ARIELA SAFMI RAMDHANI 
#14/10/2024 
#Membantu Tuan RO menentukan barang yang harus ditawarkan kepada pembeli 

# Fungsi untuk menghitung keuntungan
def hitung_keuntungan(harga_dasar, harga_jual):
    return harga_jual - harga_dasar

# Input harga dasar dan harga jual untuk masing-masing barang
harga_dasar_A = float(input("Masukkan harga dasar barang A: ")) #Variabel harga_dasar_barang_A untuk menyimpan input harga_dasar_barang_A
harga_jual_A = float(input("Masukkan harga jual barang A: ")) #Variabel harga_jual_barang_A untuk menyimpan input harga_jual_barang_A

harga_dasar_B = float(input("Masukkan harga dasar barang B: ")) #Variabel harga_dasar_barang_B untuk menyimpan harga_dasar_barang_B
harga_jual_B = float(input("Masukkan harga jual barang B: ")) #Variabel harga_jual_barang_B untuk menyimpan harga_jual_barang_B 

harga_dasar_C = float(input("Masukkan harga dasar barang C: ")) #Variabel harga_dasar_barang_C untuk menyimpan input harga_dasar_barang_C 
harga_jual_C = float(input("Masukkan harga jual barang C: ")) #Variabel harga_jual_barang_C untuk menyimpan input harga_jual_barang_C 

# Menghitung keuntungan untuk setiap barang
keuntungan_A = hitung_keuntungan(harga_dasar_A, harga_jual_A) #Variabel keuntungan_A untuk menyimpan hasil perhitungan dari harga_dasar_A & harga_jual_A 
keuntungan_B = hitung_keuntungan(harga_dasar_B, harga_jual_B) #Variabel keuntungan_B untuk menyimpan hasil perhitungan dari harga_dasar_B & harga_jual_B 
keuntungan_C = hitung_keuntungan(harga_dasar_C, harga_jual_C) #Variabel keuntungan_C untuk menyimpan hasil perhitungan dari harga_dasar_C & harga_jual_C 

# Menentukan barang dengan keuntungan terbesar
if keuntungan_A > keuntungan_B and keuntungan_A > keuntungan_C:
    barang_terbaik = "A" #Jika keuntungan_A lebih besar dari B,C, maka barang yang ditawarkan adalah barang_A 
elif keuntungan_B > keuntungan_A and keuntungan_B > keuntungan_C:
    barang_terbaik = "B" #Jika keuntungan_B lebih besar dari A,C, maka barang yang diawarkan adalah barang_B 
else:
    barang_terbaik = "C" #Jika keuntungan_C lebih besar dari A,B, maka barang yang ditawarkan adalah barang_C 

# Menampilkan hasil
print(f"Barang yang harus ditawarkan adalah barang {barang_terbaik}")