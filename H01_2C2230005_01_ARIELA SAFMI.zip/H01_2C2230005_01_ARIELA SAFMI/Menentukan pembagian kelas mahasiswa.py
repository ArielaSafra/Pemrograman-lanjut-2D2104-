#2C2230005/ARIELA SAFMI RAMDHANI 
#14/10/2024
#Menentukan pembagian kelas mahasiswa 

# Kelas berdasarkan akhiran NRP
def tentukan_kelas(nrp_akhir):
    # Mengonversi input menjadi integer
    nrp_akhir = int(nrp_akhir)

    # Menentukan kelas berdasarkan rentang NRP
    if 1 <= nrp_akhir <= 100: #jika NRP diantara 001 dan 100 
        if nrp_akhir % 2 == 0: #jika NRP genap (2) 
            return "K2" #maka (K2) menentukan NRP genap 
        else: #jika NRP ganjil 
            return "K1" #maka (K1) menentukan NRP ganjil 
    elif 101 <= nrp_akhir <= 200: #jika NRP diantara 101 dan 200 
        if nrp_akhir % 2 == 0: #jika NRP genap (2) 
            return "K4" #naka (K4) menentukan NRP genap 
        else: #jika NRP ganjil 
            return "K3" #maka (K3) menentukan NRP ganjil 
    elif 201 <= nrp_akhir <= 300: #jika NRP diantara 201 dan 300 
        if nrp_akhir % 2 == 0: #jika NRP genap (2) 
            return "K6" #maka (K6) menentukan NRP genap 
        else: #jika NRP ganjil 
            return "K5" #maka (K5) menentukan NRP ganjil 
    elif nrp_akhir > 300: #jika NRP lebih dari 300 
        if nrp_akhir % 2 == 0: #jika NRP genap (2)
            return "K8" #maka (K8) menentukan NRP genap 
        else: #jika NRP ganjil 
            return "K7" #maka (K7) menentukan NRP ganjil 
    else:
        return "NRP tidak valid" #jika NRP tidak termasuk dalam rentang yang ditentukan 

# Input akhiran NRP dari pengguna
nrp_akhir = input("Masukan akhiran NRP: ") #memasukan nilai akhiran NRP 
kelas = tentukan_kelas(nrp_akhir) #memanggil fungsi untuk menentukan kelas 

# Menampilkan hasil
print(f"Mahasiswa masuk ke kelas {kelas}") #mengeluarkan hasil yang sesuai 